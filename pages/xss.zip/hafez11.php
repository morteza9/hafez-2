<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>




<link rel="stylesheet" href="../icon-fonts/font.css">
<link rel="stylesheet" href="../css/materialize.min.css">
<link rel="stylesheet" href="../css/materialize.rtl.min.css">
<link rel="stylesheet" href="../css/mycss.css">
</head>
<body>

  <?php
require_once('pdo_create_table.php');

?>

  <nav>
    <div class="nav-wrapper teal">
      <a  href="#!" class="brand-logo center"><img class="center" src="../image/logo1-3.png" alt="" class="responsive-img"/></a>
      <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
      <ul class="right hide-on-med-and-down">
        <li><a href="../index.html">خانه</a></li>
        <li><a href="articles.html">مقالات</a></li>
        <li><a href="collapsible.html">کامپیوتر</a></li>
        <li><a href="mobile.html"> ادبیات </a></li>
     
      </ul>
    </div>
  </nav>

  <ul class="sidenav" id="mobile-demo">
    <li class="red"><a href="../index.html">خانه</a></li>
    <li class="blue-grey"><a href="articles.html">مقالات</a></li>
    <li><a href="collapsible.html">کامپیوتر</a></li>
    <li><a href="mobile.html">ادبیات</a></li>
    <li><a href="mobile.html"><img src="../image/logo1-3.png" alt="" class="circle responsive-img"/></a></li>
  </ul>
  




<div class="container">
  <div class="row">
    <div class="col s6 offset-s3 center ">
        <span class="titrbold1"> نیت کنید و به انگشت روی این دکمه اشاره ای کنید...</span>
    </div>
    <div class="col s6 offset-s3 center ">
      <div class="card-panel teal">
          <span class="white-text">

<?php   ?>

          </span>
      </div>
  </div>
</div>




<script type="text/javascript" src="../js/jquery-3.1.1.js"></script>
<script type="text/javascript" src="../js/materialize.min.js"></script>
<script type="text/javascript" src="../js/myjs.js"></script>
</body>
</html>